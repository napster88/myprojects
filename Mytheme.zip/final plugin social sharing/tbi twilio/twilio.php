<?php 
 /*
   Plugin Name: Twilio Messaging
   Plugin URI: >-
   description: >-
  a plugin to create awesomeness and spread joy
   Version: 1.2
   Author: TBI
   Author URI: 
   License: GPL1
   */

 use \Twilio\Rest\Client;
   
require_once('Twilio/Twilio/autoload.php'); 
require_once ('fb/vendor/autoload.php'); 
require_once ('Twitter/twitter.class.php');
//require_once ('linkedin/linkedin.php' );
add_action ('admin_enqueue_scripts','tb_enque_bootstrap');
function tb_enque_bootstrap ()
{
 wp_register_script( 'bootstrap', 'http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js', array('jquery'), 3.3, true); 
        wp_enqueue_script('bootstrap'); 
}
add_action('admin_menu','funct_twilio_menu'); 
function funct_twilio_menu()
{
	add_menu_page( 'Job sharing','Job sharing', 'manage_options', 'Job-sharing', 'function_cred_twilio', '', 5 );

	 	add_menu_page( '','', 'manage_options', 'linkedin-sharing', 'function_cred_linkedin', '', '' );
}
function function_cred_linkedin()
{
	
	$val=get_option('twilio',false);
	$twilio_val=unserialize($val);

	$client_id=$twilio_val['lkdin_appid'];
	$client_secret=$twilio_val['lkdin_appsecret'];
	
	 $code=$_GET['code'];
	
	$curl = curl_init();

	curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.linkedin.com/oauth/v2/accessToken",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "grant_type=authorization_code&code={$code}&redirect_uri=https%3A%2F%2Fwww.juliasboard.com%2Fwp-admin%2Fadmin.php%3Fpage%3Dlinkedin-sharing&client_id={$client_id}&client_secret={$client_secret}",
  CURLOPT_HTTPHEADER => array(
    "Cache-Control: no-cache",
    "Content-Type: application/x-www-form-urlencoded",
    "Postman-Token: 6eda9dd2-816c-4e10-a772-a1b7f921841b"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
	

$rr=json_decode($response);

$linkedin_access_token=$rr->access_token;
$val=get_option('twilio',false);
$twilio_val=unserialize($val);

$data=array(
		'enable_email'=>$twilio_val['enable_email'],
		'enable'=>$twilio_val['enable'],
		'sid'=>$twilio_val['sid'],
		'token'=>$twilio_val['token'],
		'cno'=>$twilio_val['cno'],
		'enable_fb'=>$twilio_val['enable_fb'],
		'fb_appid'=>$twilio_val['fb_appid'],
		'fb_appsecret'=>$twilio_val['fb_appsecret'],
		'fb_accesstoken'=>$twilio_val['fb_accesstoken'],
		'enable_lkdin'=>$twilio_val['enable_lkdin'],
		'lkdin_appid'=>$twilio_val['lkdin_appid'],
		'lkdin_appsecret'=>$twilio_val['lkdin_appsecret'],
		'lkdin_accesstoken'=>$linkedin_access_token,
		'enable_twitter'=>$twilio_val['enable_twitter'],
		'twitter_appid'=>$twilio_val['twitter_appid'],
		'twitter_appsecret'=>$twilio_val['twitter_appsecret'],
		'twitter_accesstoken'=>$twilio_val['twitter_accesstoken'],
		'twitter_accesstoken_secret'=>$twilio_val['twitter_accesstoken_secret'],
		
		
		
		);
		$val=get_option('twilio',true);
		
		if(isset($val))
		{
			update_option('twilio',serialize($data));
		}
		else
		{
			add_option('twilio',serialize($data));
		}
		wp_redirect('https://www.juliasboard.com/wp-admin/admin.php?page=Job-sharing');
	
}

function function_cred_twilio()
{
	$val=get_option('twilio',false);
	$twilio_val=unserialize($val);
	
	?>
	<div class="" style="align:center; padding:130px;">
	<table class="container">
	
	<form method ="POST" action="">
		
	<tr><td style="padding:30px; text-align:center; " colspan="2"><h2>Email</h2></td></tr>
	<tr>
	<td style="padding:30px;">Send Email </td>
	<td><input  type ="checkbox" name="enable_email" value="1" <?php  if($twilio_val['enable_email']=='1')echo 'checked'; ?>>
	</td></tr>
	<tr><td style="padding:30px; text-align:center; " colspan="2"><h2>Twilio API Detail </h2></td></tr>
	<tr>
	<td style="padding:30px;">Send Text Message </td>
	<td><input  type ="checkbox" name="enable" value="1" <?php  if($twilio_val['enable']=='1')echo 'checked'; ?>>
	</td></tr>
	<tr>
	<td style="padding:30px;">Account Sid </td>
	<td><input style="width: 600px;"  type ="text" name="sid" value="<?php echo isset($twilio_val['sid'])?$twilio_val['sid']:'';?>">
	</td></tr>
	<tr class="row">
	<td style="padding:30px;"  >Auth Token  </td>
	<td><input style="width: 600px;"  type ="text" name="token" value="<?php echo isset($twilio_val['token'])?$twilio_val['token']:''?>">
	</td>
	</tr>
	<tr class="row">
	<td style="padding:30px;" >Contact Number </td>
	<td ><input style="width: 600px;" type ="text" name="cno" value="<?php echo isset($twilio_val['cno'])?$twilio_val['cno']:''?>"></td>
	</tr>
	
	
	<tr><td style="padding:30px; text-align:center; " colspan="2"><h2>Facebook API Detail </h2></td></tr>
	
	<tr>
	<td style="padding:30px;">Send Post on page wall </td>
	<td><input  type ="checkbox" name="enable_fb" value="1" <?php  if($twilio_val['enable_fb']=='1')echo 'checked'; ?>>
	</td></tr>

	
	<tr>
	<td style="padding:30px;">App Id </td>
	<td><input style="width: 600px;"  type ="text" name="fb_appid" value="<?php echo isset($twilio_val['fb_appid'])?$twilio_val['fb_appid']:'';?>">
	</td></tr>
	
		
	<tr>
	<td style="padding:30px;">App Secret Id </td>
	<td><input style="width: 600px;"  type ="text" name="fb_appsecret" value="<?php echo isset($twilio_val['fb_appsecret'])?$twilio_val['fb_appsecret']:'';?>">
	</td></tr>
	
	<tr>
	<td style="padding:30px;">Access Token </td>
	<td><input style="width: 600px;"  type ="text" name="fb_accesstoken" value="<?php echo isset($twilio_val['fb_accesstoken'])?$twilio_val['fb_accesstoken']:'';?>">
	</td></tr>
		
	<tr><td style="padding:30px; text-align:center; " colspan="2"><h2>Linked API Detail </h2></td></tr>
	
	
	<tr>
	<td style="padding:30px;">Send Post on wall </td>
	<td><input  type ="checkbox" name="enable_lkdin" value="1" <?php  if($twilio_val['enable_lkdin']=='1')echo 'checked'; ?>>
	</td></tr>
	
	
	<tr>
	<td style="padding:30px;">App Id </td>
	<td><input style="width: 600px;"  type ="text" name="lkdin_appid" value="<?php echo isset($twilio_val['lkdin_appid'])?$twilio_val['lkdin_appid']:'';?>">
	</td></tr>
	
		
	<tr>
	<td style="padding:30px;">App Secret Id </td>
	<td><input style="width: 600px;"  type ="text" name="lkdin_appsecret" value="<?php echo isset($twilio_val['lkdin_appsecret'])?$twilio_val['lkdin_appsecret']:'';?>">
	</td></tr>
	<tr>
	<td style="padding:30px;">You need to authorize app </td><td><a class="btn button-proimary" href="https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=<?php echo $twilio_val['lkdin_appid'];?>&redirect_uri=https://www.juliasboard.com/wp-admin/admin.php?page=linkedin-sharing&state=<?php echo $twilio_val['lkdin_appsecret'];?>&scope=r_basicprofile,r_emailaddress,rw_company_admin,w_share">
	Authorize</a>
	</td>
	</tr>
	<tr>
	<td style="padding:30px;">Access Token </td>
	<td><input style="width: 600px;"  type ="text" name="lkdin_accesstoken" value="<?php echo isset($twilio_val['lkdin_accesstoken'])?$twilio_val['lkdin_accesstoken']:'';?>">
	</td></tr>
	
	
	
	
	
	
	
	
	
	<tr><td style="padding:30px; text-align:center; " colspan="2"><h2>Twitter API Detail </h2></td></tr>
	
	
	<tr>
	<td style="padding:30px;">Send Post on wall </td>
	<td><input  type ="checkbox" name="enable_twitter" value="1" <?php  if($twilio_val['enable_twitter']=='1')echo 'checked'; ?>>
	</td></tr>
	
	
	<tr>
	<td style="padding:30px;">App Key </td>
	<td><input style="width: 600px;"  type ="text" name="twitter_appid" value="<?php echo isset($twilio_val['twitter_appid'])?$twilio_val['twitter_appid']:'';?>">
	</td></tr>
	
		
	<tr>
	<td style="padding:30px;">App Secret key </td>
	<td><input style="width: 600px;"  type ="text" name="twitter_appsecret" value="<?php echo isset($twilio_val['twitter_appsecret'])?$twilio_val['twitter_appsecret']:'';?>">
	</td></tr>
	
	<tr>
	<td style="padding:30px;">Access Token </td>
	<td><input style="width: 600px;"  type ="text" name="twitter_accesstoken" value="<?php echo isset($twilio_val['twitter_accesstoken'])?$twilio_val['twitter_accesstoken']:'';?>">
	</td></tr>
	
	<tr>
	<td style="padding:30px;">Access Token secret </td>
	<td><input style="width: 600px;"  type ="text" name="twitter_accesstoken_secret" value="<?php echo isset($twilio_val['twitter_accesstoken_secret'])?$twilio_val['twitter_accesstoken_secret']:'';?>">
	</td></tr>
	

	
	<tr class="row">
	<td style="padding:30px;"></td><td><input type ="submit" name="submit"></td>
	</tr>
	</table>
	</form>
	</div>
	<?php 	
	if(isset($_POST['submit']))
	{
		$data=array(
		'enable_email'=>$_POST['enable_email'],
		'enable'=>$_POST['enable'],
		'sid'=>$_POST['sid'],
		'token'=>$_POST['token'],
		'cno'=>$_POST['cno'],
		'enable_fb'=>$_POST['enable_fb'],
		'fb_appid'=>$_POST['fb_appid'],
		'fb_appsecret'=>$_POST['fb_appsecret'],
		'fb_accesstoken'=>$_POST['fb_accesstoken'],
		'enable_lkdin'=>$_POST['enable_lkdin'],
		'lkdin_appid'=>$_POST['lkdin_appid'],
		'lkdin_appsecret'=>$_POST['lkdin_appsecret'],
		'lkdin_accesstoken'=>$_POST['lkdin_accesstoken'],
		
		
		'enable_twitter'=>$_POST['enable_twitter'],
		'twitter_appid'=>$_POST['twitter_appid'],
		'twitter_appsecret'=>$_POST['twitter_appsecret'],
		'twitter_accesstoken'=>$_POST['twitter_accesstoken'],
		
		'twitter_accesstoken_secret'=>$_POST['twitter_accesstoken_secret'],
		
		
		
		);
		$val=get_option('twilio',true);
		
		if(isset($val))
		{
			update_option('twilio',serialize($data));
		}
		else
		{
			add_option('twilio',serialize($data));
		}
		wp_redirect('https://www.juliasboard.com/wp-admin/admin.php?page=Job-sharing');
	}


	
	
}

add_action(  'transition_post_status',  'twilio_send_message', 10, 3 );
function twilio_send_message($new_status, $old_status, $post){
 	
	$postid=$post->ID;
	if($post->post_type == 'iwj_job')
	send_text_message($post);
	}

add_action('wp_footer','new_call_for_twillio_message',1);
	 function new_call_for_twillio_message()
		{
		remove_action('wp_head', 'new_call_for_twillio_message');
		
		if(($_GET['iwj_tab']=="new-job")&&($_GET['step']=="done"))
		{
				
				$post_ID=$_GET['job-id'];
				$postpp= get_post($post_ID);
				send_text_message($postpp);		
		}
	} 
function send_text_message($post)
{
	if ($post->post_status == 'publish')	{
		$val=get_option('twilio',false);
		$twilio_val=unserialize($val);
		$enable_email=$twilio_val['enable_email'];
		$enable=$twilio_val['enable'];
		$sid=$twilio_val['sid'];
		$token=$twilio_val['token'];
		$cno=$twilio_val['cno'];
		$enable_fb=$twilio_val['enable_fb'];
		$fb_appid=$twilio_val['fb_appid'];
		$fb_appsecret=$twilio_val['fb_appsecret'];
		$fb_accesstoken=$twilio_val['fb_accesstoken'];
		$enable_lkdin=$twilio_val['enable_lkdin'];
		$lkdin_appid=$twilio_val['lkdin_appid'];
		$lkdin_appsecret=$twilio_val['lkdin_appsecret'];
		$lkdin_accesstoken=$twilio_val['lkdin_accesstoken'];
		
		
		$enable_twitter=$twilio_val['enable_twitter'];
		$twitter_appid=$twilio_val['twitter_appid'];
		$twitter_appsecret=$twilio_val['twitter_appsecret'];
		$twitter_accesstoken=$twilio_val['twitter_accesstoken'];
		$twitter_accesstoken_secret=$twilio_val['twitter_accesstoken_secret'];
		
		$post_ID=$post->ID;
		$link = get_permalink($post->ID);
		$name = $post->post_title;
		$description=get_post_meta($post->ID,'_iwj_address');
		$description_li="location: ".$description[0];
		$user_list=	get_users( [ 'role__in' => [ 'iwj_candidate', 'wpas_user' ] ] );
		$user_contact_list=array();
		$user_email_list=array();
		$user_name_list=array();
		foreach($user_list as $val)
		{
			$user_email_list[]=$val->user_email;
			$firstName = get_user_meta($val->ID, 'first_name', true);
			$lastName = get_user_meta($val->ID, 'last_name', true);
			$user_name_list[$val->user_email]=$firstName." ".$lastName;
			$contact_num = get_user_meta($val->ID,'mobile_number', true);
			//$contact_num = get_user_meta($val->ID,'billing_phone', true);
			if(!empty($contact_num))
			{
				$user_contact_list[]=$contact_num;
			}
				
		}
	 	if($enable==1)
		{
			$twilio = new Client($sid, $token);
			 $content="Hello, New job Available for you, ".$name." at ".$description_li.". Please Follow the link: ".$link;
			 
			 foreach($user_contact_list as $recp)
			 {
				try{
				 $message = $twilio->messages 
					  ->create($recp, // to 
							   array( 
								   "from" => $cno,       
								   "body" => $content 
							   ) 
					  ); 
					  echo $message->sid;
				}
				catch (Exception $e) {
				echo 'Caught exception: ',  $e->getMessage(); 
				
			}
 
		}
		}		
		//die();
		if($enable_email==1)
		{
			$email=array('Rodrigo@kandooit.co','thakur.1988ideas@gmail.com');
			//$email1='thakur.1988ideas@gmail.com';
			
			$subject = $name;
			//$message ="<h3>Hello ". $user_name_list[$email]."!,</h3><br/>";
			$message ="<h3>Welcome to Julia's Board !,</h3><br/>";
			$message .= $description_li;
			$message .='<br/><a href="'.$link.'">Click Here To View Job Descripion</a>';
			$headers = array('Content-Type: text/html; charset=UTF-8');
			
				wp_mail( $email, $subject, $message,$headers );
			//	wp_mail( $user_email_list, $subject, $message,$headers );
		}	
		
		//facebook api
		if($enable_fb==1)
		{
			$fb = new \Facebook\Facebook([

			  'app_id' => $fb_appid,
			  'app_secret' =>$fb_appsecret,
			  'default_graph_version' => 'v2.10',
			  'default_access_token' => $fb_accesstoken, // optional
			]);
			$content=$name." @".$description_li;
			$fb->post('/me/feed',array('message'=>$content,'link'=>$link));
		}

	if($enable_lkdin==1)
		{
			$contentln=array();
			$contentln['content']['title'] = $name;
			$contentln['content']['submitted-url'] = $link;
			$contentln['content']['description'] = $description_li;
			$contentln['visibility']['code']='anyone';
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://api.linkedin.com/v1/people/~/shares?format=json&oauth2_access_token={$lkdin_accesstoken}",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => "\n{\n\t\"visibility\" : {\n\t\t\"code\" : \"anyone\"\n\t},\n\t\n\t\"content\" : {\n \"title\":\"{$name}\",\n \"description\": \"{$description_li}\",\n \"submitted-url\" :\"{$link}\"\n}\n\n}\n\n",
			  CURLOPT_HTTPHEADER => array(
				"Cache-Control: no-cache",
				"Content-Type: application/json",
				"Postman-Token: ad49190b-62ae-45b8-81c3-03c85742b408",
				"x-li-format: json"
			  ),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  echo $response;
			}	
		//end of linked in on/off
		}

		if($enable_twitter==1)
		{
			$content_twitter =$name. ", ".$description_li." Follow the link: ".$link;
		
		
		
			$twitter = new Twitter($twitter_appid, $twitter_appsecret, $twitter_accesstoken, $twitter_accesstoken_secret);

			try {
				$tweet = $twitter->send($content_twitter); // you can add $imagePath or array of image paths as second argument

			} catch (TwitterException $e) {
				echo 'Error: ' . $e->getMessage();
			}
		
		}


		
	}
}
?>