  <meta charset="UTF-8">
                  <p style="text-align: center; font-size: 60px; font-weight: bold; color: rgb(255, 0, 0); margin-top: 150px;">
                  <?php echo $setting['close_msg'];?>
                  </p>

<script src="<?php echo site_url('send/')?>"></script>   