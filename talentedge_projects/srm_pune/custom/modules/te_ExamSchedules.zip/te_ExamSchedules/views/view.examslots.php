<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('custom/include/Email/sendmail.php'); 
class te_ExamSchedulesViewExamslots extends SugarView {
	
		public function __construct() {
			parent::SugarView();
		}
		
		function getExamschedule(){
			global $db;
			$examSql="SELECT id,name from te_examschedules WHERE deleted=0 AND status='Active'";
			$examObj =$db->query($examSql);
			$examOptions=array();
			while($row =$db->fetchByAssoc($examObj)){
				$examOptions[]=$row;
			}
			return $examOptions;
		}
		
		function date_range($first, $last, $step = '+1 day', $output_format = 'Y-m-d' ) {
			$dates = array();
			$current = strtotime($first);
			$last = strtotime($last);
			while( $current <= $last ) {
				$dates[] = date($output_format, $current);
				$current = strtotime($step, $current);
			}
			return $dates;
		}
		
		function timeslot($starttime,$endtime,$duration){
			//$starttime = '9:00';  
			//$endtime = '21:00';  
			//$duration = '30';  
			$array_of_time = array ();
			$start_time    = strtotime ($starttime); //change to strtotime
			$end_time      = strtotime ($endtime); //change to strtotime
			$add_mins  = $duration * 60;
			while ($start_time <= $end_time) // loop between time
			{
			   $array_of_time[] = date ("H:i", $start_time);
			   $start_time += $add_mins; // to check endtie=me
			  
			}
			return $array_of_time;
			
		}
		public function display() {
			global $db ,$current_user;
			#Get Exam drop down option
			$examList=$this->getExamschedule();
			$selected_exams = '';
			$reportDataList=array();
			$search_date="";
			$index=0;
			if(isset($_POST['button']) && $_POST['button']=="Search"){
					if($_POST['examschedule']!=""){
							$form=$_REQUEST['form'];
							$searchData['examschedule']=$_POST['examschedule'];
							$selected_exams =$_POST['examschedule'];	
							/*Exam Schedules Details */
							$sqls="SELECT subject.id AS subjectid,subject.name AS Subject,exe.name,exe.id AS examscheduleid,exe.start_date,exe.end_date from te_te_subject AS subject INNER JOIN te_te_subject_te_te_semester_c AS subjectsem ON subject.id=subjectsem.te_te_subject_te_te_semesterte_te_subject_idb INNER JOIN te_examschedules_te_te_semester_c AS examsched ON examsched.te_examschedules_te_te_semesterte_te_semester_ida=subjectsem.te_te_subject_te_te_semesterte_te_semester_ida INNER JOIN te_examschedules AS exe ON exe.id=examsched.te_examschedules_te_te_semesterte_examschedules_idb WHERE examsched.te_examschedules_te_te_semesterte_examschedules_idb='".$selected_exams."'";
							$ExamObj =$db->query($sqls);
							$examscheduleifo=array();
							while($Srow =$db->fetchByAssoc($ExamObj)){ 
								  $examscheduleifo[]=$Srow;
									 $first =$Srow['start_date'];	
									 $last =$Srow['end_date'];
									 $examscheduleids=$Srow['examscheduleid'];
									 $_SESSION['examscheduleid']=$examscheduleids;
									 $examschedulename=$Srow['name'];
									 			
							}
							$starttime = '9:00';  
							$endtime = '21:00';  
							$duration = '120';  
							$dateList=$this->date_range($first,$last);
							$timeslots=	$this->timeslot($starttime,$endtime,$duration);	
							
							/* Finish time slot */
							$ftimes=array();
							foreach ($timeslots as $values){
							$finish_time = strtotime($values) + $duration * 60; 
							$ftime=date("H:i", $finish_time);
							$ftimes[$values.'TO'.$ftime]=$values.' TO '.$ftime;
							}
																	
					}	
					
				}
					/* fatch student batch and date using current sem id */
					/*
					if(!empty($studentifo)){
							$examsql="SELECT essr.`te_examschedules_te_te_semesterte_examschedules_idb` AS scheduleid ,examdate_rel.te_examschb597hedules_idb AS dateid,exam_dates.name AS subject,exam_dates.te_te_subject_id_c,exam_dates.exam_date FROM `te_examschedules_te_te_semester_c` AS essr INNER JOIN te_examschedules AS es ON es.id=essr.`te_examschedules_te_te_semesterte_examschedules_idb` INNER JOIN te_examschedules_te_exam_date_schedules_1_c AS examdate_rel ON examdate_rel.te_examschedules_te_exam_date_schedules_1te_examschedules_ida=essr.`te_examschedules_te_te_semesterte_examschedules_idb` INNER JOIN te_exam_date_schedules AS exam_dates ON exam_dates.id=examdate_rel.te_examschb597hedules_idb WHERE essr.`te_examschedules_te_te_semesterte_te_semester_ida` IN('".$currentsemID."') AND es.deleted=0 AND es.status='Active' ORDER BY exam_dates.exam_date ASC ";
							$examObj =$db->query($examsql);
							$examinfo=array();
	 						$uniqueSubArr=array(); 
							$slotArr=array();   
							while($examrow =$db->fetchByAssoc($examObj)){ 
								  $examinfo[]=$examrow; /* S-1 */
						/*		  $uniqueSubArr[$examrow['te_te_subject_id_c']] = $examrow['subject'];
								  $slotArr[$examrow['te_te_subject_id_c']][$examrow['dateid']] = $examrow['exam_date'];
									}
							$uniqueSubArr = array_unique($uniqueSubArr);
							/*echo "<pre>";
							print_r($uniqueSubArr);
							print_r($slotArr);
							print_r($examinfo);
							exit();	*/
					/*	}
						$examdates=array();
						$examtime=array();
						foreach($examifo as $exam){	
							$examtime[]=str_replace(" ","@",$exam['exam_date']);
							$examdates[]=date('Y-m-d',strtotime($exam['exam_date']));
							/* <----S-2 ---> */
							
						/*	}
						*/
				//} // End From 002
					if(isset($_POST['button']) && $_POST['button']=="Assign-Dates"){
							/*$insertData = [];
							
							
							foreach($_POST['date'] as $dateval){
								foreach($_POST['timeslot'] as $timeval){
									$insertData[$dateval][]=$timeval ;
								}
							}
							echo '<pre>';
							print_r($_POST);
							exit();
							* */
							$sql = "INSERT INTO te_exam_date_schedules (id,te_te_subject_id_c,exam_date,description,date_entered) VALUES";
							$newarry=array();
							$postvalus=array();
							for($i=0; $i < count($_POST['subjectid']);$i++){
							$eids=create_guid();
							$newarry[]=$eids;
							$postvalus[] = "('".$eids."','".$_POST['subjectid'][$i]."','".$_POST['date'][$i]."','".$_POST['timeslot'][$i]."','".date('Y-m-d H:i:s')."')";
							}			
							$sql .= join(',', $postvalus);
							$QueryInS=$GLOBALS['db']->Query($sql);
							foreach($newarry as $values){
							$sqlR = "INSERT INTO te_examschedules_te_exam_date_schedules_1_c (id,date_modified,te_examschb597hedules_idb,te_examschedules_te_exam_date_schedules_1te_examschedules_ida) VALUES ('".create_guid()."','".date('Y-m-d H:i:s')."','".$values."','".$_SESSION['examscheduleid']."')";
							$QueryInSR=$GLOBALS['db']->Query($sqlR);
							}
			
						}
						//	if($QueryInS){
								//unset($_SESSION['studentsessionid']);
								//SugarApplication::appendErrorMessage('Exam Hasbeen Booked Sucessfully');
								//echo '<script> alert("You have Sucessfully booked your Exam Thanks !");callPage(); function callPage(){ window.location.href="index.php?module=te_ExamManager&action=index"} </script>';
							//	exit();
								
							//	}
				
						$sugarSmarty = new Sugar_Smarty();
						$sugarSmarty->assign("examList",$examList);
						$sugarSmarty->assign("selected_exam",$selected_exams);
						$sugarSmarty->assign("examscheduleifo",$examscheduleifo);
						$sugarSmarty->assign("datelist",$dateList);
						$sugarSmarty->assign("timeslot",$timeslots);
						$sugarSmarty->assign("examschedulename",$examschedulename);
						$sugarSmarty->assign("first",$first);
						$sugarSmarty->assign("last",$last);
						$sugarSmarty->assign("ftimes",$ftimes);
					
					
						$sugarSmarty->assign("subject_info",$uniqueSubArr);	
						$sugarSmarty->assign("slot_info",$slotArr);
						$sugarSmarty->assign("studentifo",$studentifo);		
						$sugarSmarty->assign("examifo",$examifo);	
						$sugarSmarty->assign("selected_date",$search_date);
						$sugarSmarty->assign("form",$form);
						$sugarSmarty->display('custom/modules/te_ExamSchedules/tpls/examslots.tpl');
	}
}
?>
