<?php 
 //WARNING: The contents of this file are auto-generated


$dictionary['te_ExamSchedules']['fields']['exam_slot'] = array(
	'required' => false,
	'name' => 'exam_slot',
	'vname' => 'Exam Slot(In hrs)',
	'type' => 'int',
	'default'=>'',
	'audited' => false,
	'massupdate' => false,
	'studio' => 'visible',
	'len' => '20',
	'size' => '20',
	'dbType' => 'varchar',
);



/*
$dictionary['te_ExamSchedules']['fields']['start_date']['enable_range_search']=true;

$dictionary['te_ExamSchedules']['fields']['start_date']['Type']='datetimecombo';
$dictionary['te_ExamSchedules']['fields']['start_date']['dbType']='datetime';
$dictionary['te_ExamSchedules']['fields']['start_date']['options']='date_range_search_dom';

*/





// created: 2017-12-05 13:53:40
$dictionary["te_ExamSchedules"]["fields"]["te_examschedules_te_te_semester"] = array (
  'name' => 'te_examschedules_te_te_semester',
  'type' => 'link',
  'relationship' => 'te_examschedules_te_te_semester',
  'source' => 'non-db',
  'module' => 'te_te_semester',
  'bean_name' => 'te_te_semester',
  'vname' => 'LBL_TE_EXAMSCHEDULES_TE_TE_SEMESTER_FROM_TE_TE_SEMESTER_TITLE',
  'id_name' => 'te_examschedules_te_te_semesterte_te_semester_ida',
);
$dictionary["te_ExamSchedules"]["fields"]["te_examschedules_te_te_semester_name"] = array (
  'name' => 'te_examschedules_te_te_semester_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_TE_EXAMSCHEDULES_TE_TE_SEMESTER_FROM_TE_TE_SEMESTER_TITLE',
  'save' => true,
  'id_name' => 'te_examschedules_te_te_semesterte_te_semester_ida',
  'link' => 'te_examschedules_te_te_semester',
  'table' => 'te_te_semester',
  'module' => 'te_te_semester',
  'rname' => 'name',
);
$dictionary["te_ExamSchedules"]["fields"]["te_examschedules_te_te_semesterte_te_semester_ida"] = array (
  'name' => 'te_examschedules_te_te_semesterte_te_semester_ida',
  'type' => 'link',
  'relationship' => 'te_examschedules_te_te_semester',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_TE_EXAMSCHEDULES_TE_TE_SEMESTER_FROM_TE_EXAMSCHEDULES_TITLE',
);


// created: 2017-12-06 17:25:08
$dictionary["te_ExamSchedules"]["fields"]["te_examschedules_te_exam_date_schedules_1"] = array (
  'name' => 'te_examschedules_te_exam_date_schedules_1',
  'type' => 'link',
  'relationship' => 'te_examschedules_te_exam_date_schedules_1',
  'source' => 'non-db',
  'module' => 'te_Exam_Date_Schedules',
  'bean_name' => 'te_Exam_Date_Schedules',
  'side' => 'right',
  'vname' => 'LBL_TE_EXAMSCHEDULES_TE_EXAM_DATE_SCHEDULES_1_FROM_TE_EXAM_DATE_SCHEDULES_TITLE',
);

?>