  <br/>
  <footer style=" background-color:#333; height:50px;">
                                <b style="color:#fff; font-weight:normal; line-height:48px; text-align:center; margin:20px;"> All Rights Reserved . v .1.0.0</b>

		</footer>
	

	</div><!--/.fluid-container-->