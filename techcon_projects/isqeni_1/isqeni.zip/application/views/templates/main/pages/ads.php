<p style="text-align: center;"><b><?php echo $Data['name']?></b> </p>
<div align="center"><img src="<?php echo $Data['photo']?>"></div>
<p style="direction: rtl; text-align: right;"><b><?php echo $Data['text2']?></b> </p>
