<p style="text-align: center;"><b><?php echo $Data['name']?></b> </p>
<p style="direction: rtl; text-align: right;"><?php echo $Data['FeedData']?> </p>
<?php if(!empty($Data['photo'])) {?>
<div align="center"><img src="<?php echo $Data['photo']?>"></div>
<?php } ?>
<?php if(!empty($Data['photo2'])) {?>
<div align="center"><img src="<?php echo $Data['photo2']?>"></div>
<?php } ?>
<?php if(!empty($Data['photo3'])) {?>
<div align="center"><img src="<?php echo $Data['photo3']?>"></div>
<?php } ?>
<?php if(!empty($Data['photo4'])) {?>
<div align="center"><img src="<?php echo $Data['photo4']?>"></div>
<?php } ?>
<?php if(!empty($Data['photo5'])) {?>
<div align="center"><img src="<?php echo $Data['photo5']?>"></div>
<?php } ?>