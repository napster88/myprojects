 </div>
    <div class="clr"></div>
</div>

	<div style="display: none;">
		<div id="inline" style="width:320px;height:140px;overflow:hidden;">
            <form action="<?php echo site_url("users")?>" method="post">
                        	<input type="text" name="txtUserName" title="اسم المستخدم"  placeholder="اسم المستخدم" value="" />
                <input type="password" name="txtPassword" title="كلمة المرور" placeholder="كلمة المرور" value="" />
                <input type="submit" value="اتمام عملية التسجيل" />
            </form>
		</div>

	</div>

</body>
</html>