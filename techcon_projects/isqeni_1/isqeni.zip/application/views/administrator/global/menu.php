<div class="container-fluid">
		<div class="row-fluid">
			<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li class="nav-header hidden-tablet"><?=lang("Home")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/home")?>"><i class="icon-home"></i><span class="hidden-tablet"> <?php echo lang("Messages")?> <span style="color: yellow; font-size: 13px; font-weight: bold;">( <?php echo $this->data->countTable("contact",array("read"=>"0"));?> )</span></span></a></li>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("3",$this->session->userdata('permi'))) { ?>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/about")?>"><i class="icon-home"></i><span class="hidden-tablet"> <?=lang("AboutApp")?> </span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/conditions")?>"><i class="icon-home"></i><span class="hidden-tablet"> <?=lang("Termsandconditions")?> </span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("2",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"> <?=lang("Setting")?></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/settings/")?>"><i class="icon-wrench"></i><span class="hidden-tablet"> <?=lang("GeneralSetting")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/settings/noti/")?>"><i class="icon-wrench"></i><span class="hidden-tablet"> <?=lang("SendNotify")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("4",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?=lang("Companies")?></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/cats/")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/cats/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("5",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"> <?=lang("Products")?></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/products/")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/products/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("6",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?=lang("RegisteredCustomers")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/clients/")?>"><i class="icon-user"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/clients/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("7",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet">  <?=lang("PurchaseordersandSales")?></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/orders/")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/orders/companies")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?=lang("ShowByCompanies")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("8",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?=lang("ManagePerm")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/group/")?>"><i class="icon-user"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/group/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("8",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?=lang("Management")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/users/")?>"><i class="icon-user"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li><a class="ajax-link" href="<?php echo site_url("administrator/users/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("9",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?php echo lang("Complaints")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/complaints/")?>"><i class="icon-wrench"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                        <li class="nav-header hidden-tablet"><?php echo lang("Rates")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/question/")?>"><i class="icon-wrench"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>						
                        <?php } ?>
                        <?php if (in_array("1",$this->session->userdata('permi')) || in_array("9",$this->session->userdata('permi'))) { ?>
                        <li class="nav-header hidden-tablet"><?php echo lang("Maintenance")?></li>
						<li><a class="ajax-link" href="<?php echo site_url("administrator/maintenance/backup")?>"><i class="icon-wrench"></i><span class="hidden-tablet"> <?php echo lang("Backup")?></span></a></li>
                        <?php } ?>
                    </ul>
				</div><!--/.well -->
			</div><!--/span-->
			<!-- left menu ends -->



			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>