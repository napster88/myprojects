<div class="container-fluid">
		<div class="row-fluid">
			<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
				  <ul class="nav nav-tabs nav-stacked main-menu">
                              <!--<li class="nav-header hidden-tablet">المنتجات</li>
                              <li><a class="ajax-link" href="<?php echo site_url("products/")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                              <li><a class="ajax-link" href="<?php echo site_url("products/add")?>"><i class="icon-plus-sign"></i><span class="hidden-tablet"> <?php echo lang("Add")?></span></a></li>-->
                              <li class="nav-header hidden-tablet"><?php echo lang("PurchaseordersandSales")?></li>
                              <li><a class="ajax-link" href="<?php echo site_url("orders/")?>"><i class="icon-globe"></i><span class="hidden-tablet"> <?php echo lang("Show")?></span></a></li>
                          </ul>
				</div><!--/.well -->
			</div><!--/span-->
			<!-- left menu ends -->
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>