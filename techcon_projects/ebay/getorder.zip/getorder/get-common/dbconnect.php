<?php
define("DB_NAME", "ebay_tracking_system");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_HOST", "localhost");
$dbc = mysqli_connect (DB_HOST, DB_USER, DB_PASS, DB_NAME);

?>