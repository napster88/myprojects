<?php

require_once __DIR__ . '/vendor/autoload.php'; // change path as needed

$fb = new \Facebook\Facebook([
  'app_id' => '470242060045959',
  'app_secret' => '3d37609b29a742b3ee952d0b24cad13e',
  'default_graph_version' => 'v2.10',
  'default_access_token' => 'EAAGrrsLyjocBANBZA0oPermkiFCsMtT5KZAkABViiv0cDnqN1VEAxoZBeF5nYXgjS9Xy1YvbwtwWOXApGhIbWrzMZCPZCO7t8nZAwYAo1sqXQ3iywQkIC1hNQaQZAoo5ZAN27c5gtFSqNkVRPxaFBTx1NAxnY7W8ZCqIqMYZBb7S5zFA90zpmmNByJn0GmHOb5JOhBy4oqpWMF6bvxwt0BfdWZB', // optional
]);

// Use one of the helper classes to get a Facebook\Authentication\AccessToken entity.
//   $helper = $fb->getRedirectLoginHelper();
//   $helper = $fb->getJavaScriptHelper();
//   $helper = $fb->getCanvasHelper();
//   $helper = $fb->getPageTabHelper();

try {
  // Get the \Facebook\GraphNodes\GraphUser object for the current user.
  // If you provided a 'default_access_token', the '{access-token}' is optional.
  $response = $fb->get('/me');
} catch(\Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(\Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$me = $response->getGraphUser();
echo 'Logged in as ' . $me->getName();
 $fb->post('/me/feed',array('message'=>"kapil testing you post"));