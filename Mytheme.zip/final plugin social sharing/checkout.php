<?php

/* @var $this yii\web\View */



//$this->title = 'My Yii Application';





?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!--<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="jquery-3.3.1.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.0.1/jquery-migrate.js"></script>


<?php 





?>
<script>
jQuery(document).ready(function(){
	
	var shipping_available='';
jQuery.getJSON('/cart.js', function(cart) {
  console.log(cart);
  
  //console.log(cart.items.length());
  jQuery('.total_price').text(cart.currency+" "+cart.total_price/100);
  jQuery('.total_quantity').text(cart.item_count);
   jQuery('.total_discount').text(cart.total_discount);
    shipping_available=jQuery('.requires_shipping').text(cart.requires_shipping);
   jQuery.each( cart.items, function( key, value ) {

		jQuery('.item_row').append('<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">'+value.title +'</span>  <span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">'+value.quantity +'</span>   <span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">'+cart.currency+" "+value.price/100+'</span> <span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">'+cart.currency+" "+value.line_price/100+'</span>   ');
  
	});
  
});
	
	
	
	jQuery('.same_as_shipping').change(function(){
		if(jQuery(this).prop("checked"))
		{
			var billing_first_name=jQuery('.billing_first_name').val();
			var billing_last_name=jQuery('.billing_last_name').val();
			var billing_address=jQuery('.billing_address').val();
			var billing_apartment=jQuery('.billing_apartment').val();
			var billing_city=jQuery('.billing_city').val();
			var billing_country=jQuery('.billing_country').val();
			var billing_state=jQuery('.billing_state').val();
			var billing_postal=jQuery('.billing_postal').val();
			
			jQuery('.shipping_first_name').val(billing_first_name);
			jQuery('.shipping_last_name').val(billing_last_name);
			jQuery('.shipping_address').val(billing_address);
			jQuery('.shipping_apartment').val(billing_apartment);
			jQuery('.shipping_city').val(billing_city);
			jQuery('.shipping_country').val(billing_country);
			jQuery('.shipping_state').val(billing_state);
			jQuery('.shipping_postal').val(billing_postal);
			//if(shipping_available==true)
			{
				//alert();
				jQuery.getJSON('/cart/shipping_rates.json?shipping_address%5Bzip%5D='+billing_postal+'&shipping_address%5Bcountry%5D='+billing_country+'&shipping_address%5Bprovince%5D='+billing_state, function(shiiping) {
					console.log(shiiping['shipping_rates']);
					jQuery('.shipping_row').empty();
					 jQuery.each( shiiping['shipping_rates'], function( key, value ) {
						 
						jQuery('.shipping_row').append('<input type="button"  name="shipping_detail" class="shipping_method" attr="'+value.price+'" value="'+value.code+'"> '+value.name+'('+value.price+')<br/>');    
					 });
					
				
				});
			}
		}
		else
		{
			jQuery('.shipping_first_name').val('');
			jQuery('.shipping_last_name').val('');
			jQuery('.shipping_address').val('');
			jQuery('.shipping_apartment').val('');
			jQuery('.shipping_city').val('');
			jQuery('.shipping_country').val('');
			jQuery('.shipping_state').val('');
			jQuery('.shipping_postal').val('');
		}

	});
	
	
	
	
});

	jQuery('.shipping_method').on("click",function(){
		alert();
		var val=jQuery(this).attr('attr');
		jQuery('.requires_shipping').text(val);
	});
	

</script>
<br>
<div class="container">
<div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12"> Product Information</span>
</div></div>
<div class="container">

<div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 color-container">


<div class="row color-row">
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">Item </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3">Quantity </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> Price</span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> Total</span>
</div>
<div class="row item_row border-row">
</div>
<div class="row">
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3 "> Discount</span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3 total_discount"> </span>
</div>
<div class="row ">
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> Shipping</span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3 requires_shipping"> </span>
</div>
<div class="row color-row">
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> Total</span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3 total_quantity"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3"> </span>
<span class="col-lg-3 col-md-3 col-sm-3 col-sx-3 total_price"> </span>
</div>
</div>

<div class="row">
<span class="col-lg-3 col-md-3 col-sm-12 col-sx-12"> Billing Address</span>
</div>

 <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12"> <input type="text" class="field__input" placeholder="Email / Contact number"> </span>
</div>
<div class="row">
<span class="col-lg-3 col-md-3 col-sm-12 col-sx-12">Address</span>
</div>

 <div class="row">
<span class="col-lg-6 col-md-6 col-sm-6 col-sx-6">  <input type="text" class="billing_first_name field__input" placeholder="First Name (Optional)">  </span>
<span class="col-lg-6 col-md-6 col-sm-6 col-sx-6">  
 <input type="text" class="field__input billing_last_name" placeholder="Last Name">  </span>

</div>

 <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12">  <input type="text" class="billing_address field__input" placeholder="Address">  </span>
</div>

 <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12"> <input type="text" class="billing_apartment field__input" placeholder="Apartment, suite, etc. (optional)">   </span>
</div>
  <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12">  <input type="text" class="billing_city field__input" placeholder="City">   </span>
</div>

<div class="row">
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12"> <input type="text" class="billing_country field__input" placeholder="Country"> </span>
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12 "> <input type="text" class="billing_state field__input" placeholder="State"> </span>
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12"> <input type="text" class="billing_postal field__input" placeholder="Postal Code"> </span>
</div>


<div class="row">
<span class="col-lg-3 col-md-3 col-sm-12 col-sx-12"> <input type="checkbox" class="same_as_shipping" value="1"> Same as Billing address</span>
</div>



<div class="row">
<span class="col-lg-3 col-md-3 col-sm-12 col-sx-12"> Shipping Address</span>
</div>

<div class="row">
<span class="col-lg-3 col-md-3 col-sm-12 col-sx-12">Address</span>
</div>

 <div class="row">
<span class="col-lg-6 col-md-6 col-sm-6 col-sx-6">  <input type="text" class="shipping_first_name field__input" placeholder="First Name (Optional)">  </span>
<span class="col-lg-6 col-md-6 col-sm-6 col-sx-6">  
 <input type="text" class="field__input shipping_last_name" placeholder="Last Name">  </span>

</div>

 <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12">  <input type="text" class="shipping_address field__input" placeholder="Address">  </span>
</div>

 <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12"> <input type="text" class="shipping_apartment field__input" placeholder="Apartment, suite, etc. (optional)">   </span>
</div>
  <div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12">  <input type="text" class="shipping_city field__input" placeholder="City">   </span>
</div>

<div class="row">
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12"> <input type="text" class="shipping_country field__input" placeholder="Country"> </span>
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12 "> <input type="text" class="shipping_state field__input" placeholder="State"> </span>
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12"> <input type="text" class="shipping_postal field__input" placeholder="Postal Code"> </span>
</div>







<div class="row shipping_row border-row">
<span class="col-lg-4 col-md-4 col-sm-12 col-sx-12"> Shipping detail </span>

</div>


 
<div class="row">
<span class="col-lg-12 col-md-12 col-sm-12 col-sx-12">  <input  type="text" class="field__input" placeholder="Payment method
All transactions are secure and encrypted.">  </span>
</div>


</div>

 
<style>
.border-row
{
	border-bottom:1px solid #eee; 
}
.color-row
{
	background:#eee;
}
.color-container
{
	

    border: 1px solid #ddd;
    border-radius: 10px;
  /*   padding-top: 7px; */
}
.row{
	padding:10px;
}
{
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", sans-serif;
}

.field__input {
    border: 1px transparent solid;
    background-clip: padding-box;
    border-radius: 5px;
    display: block;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    width:100%;
    padding: 0.92857em 0.78571em;
    word-break: normal;
	background-color: white;
    color: #333333;
    border-color: #d9d9d9;
}
</style>
 <?php   die();  ?>