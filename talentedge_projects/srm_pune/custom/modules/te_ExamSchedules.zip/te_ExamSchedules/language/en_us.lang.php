<?php
// created: 2017-12-27 18:50:48
$mod_strings = array (
  'LBL_TE_EXAMSCHEDULES_TE_EXAM_DATE_SCHEDULES_1_FROM_TE_EXAM_DATE_SCHEDULES_TITLE' => 'Exam Date Schedules',
  'LBL_START_DATE' => 'Start Date',
);