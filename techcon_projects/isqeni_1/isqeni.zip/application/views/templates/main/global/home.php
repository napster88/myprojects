<html dir="rtl">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>:: &#1578;&#1591;&#1576;&#1610;&#1602; &#1602;&#1576;&#1610;&#1604;&#1577; &#1605;&#1591;&#1610;&#1585; ::</title>
</head>

<body bgcolor="#84CADA">

<p align="center"><img border="0" src="<?php echo base_url()?>images/mutair-logo.gif" loop="0"></p>

</body>

</html>
